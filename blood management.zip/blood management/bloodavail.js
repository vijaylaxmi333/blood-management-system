const express = require('express');
const app = express();
const port = 3000;

// Temporary in-memory data storage
const bloodAvailabilityData = [
    { bloodGroup: 'A+', unitsAvailable: 5 },
    { bloodGroup: 'B-', unitsAvailable: 8 },
    // Add more blood group entries as needed
];

const donorAvailabilityData = [
    { donorName: 'John Doe', bloodGroup: 'A+', contactNumber: '1234567890' },
    { donorName: 'Jane Smith', bloodGroup: 'B-', contactNumber: '9876543210' },
    // Add more donor availability details as needed
];

// Serve HTML, CSS, and JS files
app.use(express.static('public'));

// Endpoint to get blood availability data
app.get('/api/bloodAvailability', (req, res) => {
    res.json(bloodAvailabilityData);
});

// Endpoint to get donor availability data
app.get('/api/donorAvailability', (req, res) => {
    res.json(donorAvailabilityData);
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
