const express = require('express');
const app = express();
const port = 3000;

// Blood availability data (temporary in-memory data)
const bloodAvailabilityData = [
    { bloodGroup: 'A+', unitsAvailable: 5 },
    { bloodGroup: 'B-', unitsAvailable: 8 },
    // Add more blood group entries as needed
];

// Serve HTML, CSS, and JS files
app.use(express.static('public'));

// Endpoint to get blood availability data
app.get('/api/bloodAvailability', (req, res) => {
    res.json(bloodAvailabilityData);
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
