const express = require('express');
const app = express();
const port = 3000;
async function fetchBloodAvailability() {
    try {
        const response = await fetch('/api/bloodAvailability');
        const data = await response.json();

        // Update the table with fetched data
        var table = document.getElementById("bloodTable").getElementsByTagName('tbody')[0];
        table.innerHTML = "";

        data.forEach(function(bloodData) {
            var newRow = table.insertRow(table.rows.length);
            var cell1 = newRow.insertCell(0);
            var cell2 = newRow.insertCell(1);
            cell1.innerHTML = bloodData.bloodGroup;
            cell2.innerHTML = bloodData.unitsAvailable;
        });

    } catch (error) {
        console.error('Error fetching blood availability:', error);
    }
}

// Call this function when the button is clicked
document.querySelector('input[value="Blood Available"]').addEventListener('click', fetchBloodAvailability);


// Temporary in-memory data storage
const bloodAvailabilityData = [
    { bloodGroup: 'A+', unitsAvailable: 5 },
    { bloodGroup: 'B-', unitsAvailable: 8 },
    // Add more blood group entries as needed
];

const donorAvailabilityData = [
    { donorName: 'John Doe', bloodGroup: 'A+', contactNumber: '1234567890' },
    { donorName: 'Jane Smith', bloodGroup: 'B-', contactNumber: '9876543210' },
    // Add more donor availability details as needed
];

// Serve HTML, CSS, and JS files
app.use(express.static('public'));

// Endpoint to get blood availability data
app.get('/api/bloodAvailability', (req, res) => {
    res.json(bloodAvailabilityData);
});

// Endpoint to get donor availability data
app.get('/api/donorAvailability', (req, res) => {
    res.json(donorAvailabilityData);
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
